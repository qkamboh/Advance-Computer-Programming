/*
 *       Filename:  Welcome4.java
 *
 *    Description:  Fig. 2.6: Displaying multiple lines with method
 *                  System.out.printf
 *
 *        Created:  25/09/15 23:39:04
 *       Revision:  none
 *
 *        @Author:  Siidney Watson - siidney.watson.work@gmail.com
 *       @Version:  1.0
 *
 * =====================================================================================
 */
public class Welcome4{
    public static void main(String[] args){
        System.out.printf("%s\n%s\n", "Welcome to ", "Java Programming!");
    }
}
