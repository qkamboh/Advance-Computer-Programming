/*
 *       Filename:  Welcome2.java
 *
 *    Description:  Fig. 2.3: Printing a line of text with multiple statements
 *
 *        Created:  25/09/15 23:39:04
 *       Revision:  none
 *
 *        @Author:  Siidney Watson - siidney.watson.work@gmail.com
 *       @Version:  1.0
 *
 * =====================================================================================
 */
public class Welcome2{
    public static void main(String[] args){
        System.out.println("Welcome to ");
        System.out.println("Java programming!");
    }
}
