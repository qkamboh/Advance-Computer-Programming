These exercises need completing.

I do not fully understand the questions either due to poor wording, or lack of
understanding on my part.

This will be returned to at a later date.
