/*
 *       Filename:  ATMCaseStudy.java
 *
 *    Description:  13.24 - Driver program for ATM case study
 *
 *        Created:  05/12/15 05:14:43
 *       Revision:  none
 *
 *        @Author:  Siidney Watson - siidney.watson.work@gmail.com
 *       @Version:  1.0
 *
 * =====================================================================================
 */
public class ATMCaseStudy{
    public static void main(String[] args){
        ATM theATM = new ATM();

        theATM.run();
    }
}
