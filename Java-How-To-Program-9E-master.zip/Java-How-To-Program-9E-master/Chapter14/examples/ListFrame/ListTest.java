/*
 *       Filename:  ListTest.java
 *
 *    Description:  14.24 - selecting colours from a JList
 *
 *        Created:  11/12/15 17:47:51
 *       Revision:  none
 *
 *        @Author:  Siidney Watson - siidney.watson.work@gmail.com
 *       @Version:  1.0
 *
 * =====================================================================================
 */
import javax.swing.JFrame;

public class ListTest{
    public static void main(String[] args){
        ListFrame listFrame = new ListFrame();
        listFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        listFrame.setSize(350, 150);
        listFrame.setVisible(true);
    }
}
