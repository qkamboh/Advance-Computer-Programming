##Deitel and Deitel - Java How to Program 9th Edition

####My solutions to most, eventually all, of the books problems.
> - Also contains the example programs used to introduce topics.

This is a wip and is being used as a tool for learning Java so don't expect
perfection right off of the bat.

I am also not mathematically proficient in the slightest so some of the
solutions may not be done in the most efficient, or even correct, way.

##Chapter List (Updated as they are started)

> - **Chapter 1**  - Introduction to Computing
> - **Chapter 2**  - [Introduction to Java Applications](https://github.com/siidney/Java-How-To-Program-9E/tree/master/Chapter2)
> - **Chapter 3**  - [Introduction to Classes, Objects, Methods and Strings](https://github.com/siidney/Java-How-To-Program-9E/tree/master/Chapter3)
> - **Chapter 4**  - [Control Statements: Part 1](https://github.com/siidney/Java-How-To-Program-9E/tree/master/Chapter4)
> - **Chapter 5**  - [Control Statements: Part 2](https://github.com/siidney/Java-How-To-Program-9E/tree/master/Chapter5)
> - **Chapter 6**  - [Methods: A Deeper Look](https://github.com/siidney/Java-How-To-Program-9E/tree/master/Chapter6)
> - **Chapter 7**  - [Arrays and ArrayLists](https://github.com/siidney/Java-How-To-Program-9E/tree/master/Chapter7)
> - **Chapter 8**  - [Classes and Objects: A Deeper Look](https://github.com/siidney/Java-How-To-Program-9E/tree/master/Chapter8)
> - **Chapter 9**  - [Object-Oriented Programming: Inheritence](https://github.com/siidney/Java-How-To-Program-9E/tree/master/Chapter9)
> - **Chapter 10** - [Object-Oriented Programming: Polymorphism](https://github.com/siidney/Java-How-To-Program-9E/tree/master/Chapter10)
> - **Chapter 11** - [Exception Handling: A Deeper Look](https://github.com/siidney/Java-How-To-Program-9E/tree/master/Chapter11) - *incomplete*
> - **Chapter 12** - [ATM Case Study, Part 1: Object-Oriented Design with the
>   UML](https://github.com/siidney/Java-How-To-Program-9E/tree/master/Chapter12)
> - **Chapter 13** - [ATM Case Study, Part 2: Implementing an Object-Oriented Design](https://github.com/siidney/Java-How-To-Program-9E/tree/master/Chapter13)
> - **Chapter 14** - [GUI Components: Part 1](https://github.com/siidney/Java-How-To-Program-9E/tree/master/Chapter14) - *in progress*
> - **Chapter 15** - Graphics and Java 2D
> - **Chapter 16** - Strings, Character and Regular Expressions
> - **Chapter 17** - Files, Streams and Object Serialization
> - **Chapter 18** - Recursion
> - **Chapter 19** - Searching, Sorting and Big O
> - **Chapter 20** - Generic Collections
> - **Chapter 21** - Generic Classes and Methods
> - **Chapter 22** - Custom Generic Data Structures
> - **Chapter 23** - Applets and Java Web Start
> - **Chapter 24** - Multimedia: Applets and Applications
> - **Chapter 25** - GUI Components: Part 2
> - **Chapter 26** - Multithreading
> - **Chapter 27** - Networking
> - **Chapter 28** - Accessing Databases with JDBC
> - **Chapter 29** - JavaServer Faces Web Apps: Part 1
> - **Chapter 30** - JavaServer Faces Web Apps: Part 2
> - **Chapter 31** - Web Services
