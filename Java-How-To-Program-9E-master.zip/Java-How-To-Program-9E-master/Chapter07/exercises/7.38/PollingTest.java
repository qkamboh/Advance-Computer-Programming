/*
 *       Filename:  PollingTest.java
 *
 *    Description:  Exercise 7.38 - Polling
 *
 *        Created:  21/10/15 23:54:58
 *       Revision:  none
 *
 *        @Author:  Siidney Watson - siidney.watson.work@gmail.com
 *       @Version:  1.0
 *
 * =====================================================================================
 */
public class PollingTest{
    public static void main(String[] args){
        Polling polling = new Polling();

        polling.run();
    }
}
