####Not started exercises

The following were not started as they seemed unnecesarily boring and I haven't
the patience nor inclination for them.

That being said however, I may attempt them at a future date.

> - **7.22** - Knight's Tour
> - **7.23** - Knight's Tour: Brute-Force Approach
> - **7.24** - Eight Queens
> - **7.25** - Eight Queens: Brute-Force Approach
> - **7.26** - Knight's Tour: Closed-Tour Test

The follwing weren't done as I don't understand the rules to poker so didn't
feel as though I could accurately reproduce it.

> - **7.30** - Card Shuffling and Dealing
> - **7.31** - Card Shuffling and Dealing
> - **7.32** - Project: Card Shuffling and Dealing
> - **7.33** - Project: Card Shuffling and Dealing
> - **7.34** - Project: Card Shuffling and Dealing
