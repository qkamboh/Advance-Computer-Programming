/*
 *       Filename:  MachineLanguageProgrammingTest.java
 *
 *    Description:  Exercise 7.35-7.37 - Machine-Language Programming
 *
 *        Created:  20/10/15 19:36:58
 *       Revision:  none
 *
 *        @Author:  Siidney Watson - siidney.watson.work@gmail.com
 *       @Version:  1.0
 *
 * =====================================================================================
 */
public class MachineLanguageProgrammingTest{
    public static void main(String[] args){
        MachineLanguageProgramming SML = new MachineLanguageProgramming();

        SML.run();
    }
}
