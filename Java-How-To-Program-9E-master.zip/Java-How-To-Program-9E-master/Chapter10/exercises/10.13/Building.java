/*
 *       Filename:  Building.java
 *
 *    Description:  Exercise 10.13 - CarbonFootprint Interface: Polymorphism
 *
 *                  TODO : Finish this. Am bored of this now so won't be
 *                  continuing.
 *
 *        Created:  19/11/15 15:26:48
 *       Revision:  none
 *
 *        @Author:  Siidney Watson - siidney.watson.work@gmail.com
 *       @Version:  1.0
 *
 * =====================================================================================
 */
public class Building implements CarbonFootprint{
    // calculate carbon footprint
    @Override
    public double getCarbonFootprint(){
        return 0.0f;
    }
}
