/*
 *       Filename:  CarbonFootprint.java
 *
 *    Description:  Exercise 10.13 - CarbonFootprint Interface: Polymorphism
 *
 *        Created:  19/11/15 15:30:10
 *       Revision:  none
 *
 *        @Author:  Siidney Watson - siidney.watson.work@gmail.com
 *       @Version:  1.0
 *
 * =====================================================================================
 */
public interface CarbonFootprint{
    public double getCarbonFootprint();
}
