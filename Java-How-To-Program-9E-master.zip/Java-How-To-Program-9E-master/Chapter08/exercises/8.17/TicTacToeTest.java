/*
 *       Filename:  TicTacToeTest.java
 *
 *    Description:  Exercise 8.17 - Tic-Tac-Toe
 *
 *        Created:  04/11/15 18:21:41
 *       Revision:  none
 *
 *        @Author:  Siidney Watson - siidney.watson.work@gmail.com
 *       @Version:  1.0
 *
 * =====================================================================================
 */
public class TicTacToeTest{
    public static void main(String[] args){
        TicTacToe ttt = new TicTacToe();

        ttt.run();
    }
}
