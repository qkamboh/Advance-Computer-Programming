Have discovered the go to algorithm for this is minimax so as soon as I have the
time/inclination I shall properly understand and implement it.
